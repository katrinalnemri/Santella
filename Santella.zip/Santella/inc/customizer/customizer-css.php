<?php
add_action( 'customize_controls_print_styles', 'customizer_enqueue_styles', 999 );
//This function adds some styles to the WordPress Customizer
function customizer_enqueue_styles() { ?>
	<style>
  
  </style>
<?php }
