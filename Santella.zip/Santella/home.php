<?php
/**
* Home
*
* @package santella
* @since santella 1.0
*/

get_template_part('page-templates/bfd-home');